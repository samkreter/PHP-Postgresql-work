<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br><strong>Delete was successful</strong>
	Return to <a href="index.php" data-reveal-id="insert-modal">Search Page</a>
</body>
</html>