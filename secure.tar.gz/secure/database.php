<?php 

DEFINE(“HOST”,”host=dbhost-pgsql.cs.missouri.edu”);

DEFINE(“DBNAME”,”dbname=sakfy6”);

DEFINE(“USERNAME”,”user=sakfy6”);

DEFINE(“PASSWORD”,”password=3rAHuCgc”);

?>
